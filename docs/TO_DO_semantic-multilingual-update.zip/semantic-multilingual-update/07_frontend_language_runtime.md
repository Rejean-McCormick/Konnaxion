# Frontend Language Runtime

**Status:** Architecture proposal

## 1. Goal

The frontend should make language selection as simple for the user as theme selection while preserving the semantic architecture underneath.

## 2. Language context

Introduce a global language/locale state similar in lifecycle to theme state.

Conceptual API:

```ts
type AppLocale = 'en' | 'fr-CA' | 'fr'

interface LanguageContextValue {
  locale: AppLocale
  setLocale(locale: AppLocale): void
}
```

Responsibilities:

- persist user preference;
- update `document.documentElement.lang`;
- select Ant Design locale;
- select application message catalog;
- send locale to Konnaxion APIs;
- request correct domain representations;
- never alter route/object identity solely because language changed.

## 3. UI chrome catalog

Static product messages should use stable message keys.

Example:

```ts
t('ethikos.deliberate.openThread')
```

not:

```ts
locale === 'fr' ? 'Ouvrir...' : 'Open...'
```

The choice of library may be made separately. The architecture only requires stable keys, BCP-47 locale handling and deterministic fallback.

## 4. Domain content

The frontend MUST NOT keep independent hard-coded translations of database topic content.

For domain objects:

```text
API returns representation selected for locale
→ component renders it
→ metadata indicates fallback/translation when relevant
```

## 5. User-authored translations

If a displayed contribution is translated, the UI SHOULD allow the user to identify that fact and access the original where policy permits.

Candidate affordance:

```text
Translated from French (Canada) · View original
```

This should be compact and non-disruptive.

## 6. Locale switch behavior

Switching locale should:

- keep the same route when possible;
- keep the same topic/argument selected;
- keep drawers/modals open where safe;
- refresh representation data;
- preserve unsaved form content;
- change date/number formatting;
- change accessible names and labels;
- not reset Smart Vote/EkoH state.

## 7. Routes

Initial recommendation: do not encode locale into every route until there is a concrete SEO/public-routing requirement.

Prefer:

```text
/ethikos/deliberate/73?sidebar=ethikos
```

with locale from user/session/application state.

If locale-prefixed public routes are later required, that becomes a separate routing ADR.

## 8. Accessibility

Translated UI labels must also translate accessible names.

Ariane must not depend on those localized names as stable identity.

Example:

```html
<button aria-label="Voir les lectures">...</button>
```

and

```html
<button aria-label="View readings">...</button>
```

may represent the same Ariane ElementConcept/Transition.

## 9. Semantic automation hooks

Where useful, Konnaxion MAY expose explicit machine-readable hints to Ariane, but those hints must align with Ariane's existing registries.

Candidate:

```html
<button
  data-ariane-intent="qi_ethikos_view_readings"
  data-kx-object="kx:smart-vote:consultation:..."
>
  {t('smartVote.viewReadings')}
</button>
```

This is a proposed integration hint, not yet a normative Ariane field. It requires Ariane/Konnaxion agreement before broad adoption.

## 10. Test selectors

Playwright and Cinematic Engine should migrate away from visible-language selectors when stable app hooks exist.

Preferred priority:

```text
stable data-testid / semantic test hook
→ role + stable non-linguistic hook
→ localized role/name only as behavioral assertion
```

Tests SHOULD still assert that the correct translated text is visible, but translation text should not be the locator for unrelated behavior.
