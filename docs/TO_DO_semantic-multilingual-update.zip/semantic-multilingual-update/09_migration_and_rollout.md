# Migration and Rollout Plan

**Status:** Architecture proposal

## 1. Strategy

This is a major semantic refactor, but it should be delivered as an additive migration rather than a rewrite.

Use staged compatibility windows.

## 2. Phase 0 — Contract and inventory

Before migrations:

- approve the architecture ADR;
- inventory text fields used as identity or lookup keys;
- inventory importers matching on title/name/content;
- inventory frontend selectors relying on visible language;
- inventory API clients that assume one language;
- inventory seed data language;
- define supported BCP-47 locales for V1;
- define the English fallback policy;
- define Konnaxion semantic key format;
- define semantic binding relation vocabulary.

Exit gate: no implementation begins until identity and fallback rules are explicit.

## 3. Phase 1 — Stable identity first

Add stable language-neutral keys before adding multiple representations.

Priorities:

1. EthikosCategory key.
2. EthikosTopic semantic/domain key.
3. Stable seed/import mapping.
4. Semantic binding model.

Change importers from:

```text
lookup by title/name
```

to:

```text
lookup by stable key
```

Exit gate: translating a seed title cannot create a duplicate topic.

## 4. Phase 2 — Representation storage

Add representation models and original-language metadata.

Backfill existing data:

- existing maintained demo/institutional English data → `canonical_editorial`;
- existing French institutional content → `original` or curated representation according to provenance;
- existing user arguments → preserve exact current content as `original` with known/detected language.

Do not machine-translate the entire database as part of schema migration.

## 5. Phase 3 — API compatibility projection

Add locale-aware representation resolution while preserving old fields.

```text
old client
GET topic
→ title/description populated from default English projection

new client
GET topic?lang=fr-CA
→ title/description populated from resolver
→ representation metadata included
```

Exit gate: existing clients pass unchanged regression tests.

## 6. Phase 4 — Frontend language runtime

Add:

- locale context;
- persistent preference;
- Ant Design locale selection;
- UI message catalogs;
- API locale propagation;
- translated representation indicators;
- original-content access.

Exit gate: switching locale preserves current domain object and application state.

## 7. Phase 5 — Kristal/SenTient semantic bindings

Start with high-value objects rather than resolving every string in the system.

Initial target:

- demo topics;
- topic entities/organizations/jurisdictions;
- source entities;
- selected domain taxonomy terms.

Use pinned Wikidata/Kristal source snapshots and preserve resolution provenance.

Exit gate: same Konnaxion topic can be discovered from at least English and French semantic/lexical queries.

## 8. Phase 6 — Architect rendering

Adopt Architect only for outputs that benefit from knowledge-backed deterministic rendering.

Candidate first surfaces:

- semantic entity descriptions;
- knowledge context cards;
- traceable factual summaries;
- explainability blocks.

Do not block ordinary UI localization on Architect availability.

## 9. Phase 7 — Ariane multilingual conformance

Update Ariane integration so language changes are recognized as lexical/context changes rather than new application identities.

Add stable hooks where needed.

Exit gate: one Ariane route/flow works under both `en` and `fr-CA` with the same state/element/transition concepts.

## 10. Phase 8 — Seed conversion

Only after stable identity and representations exist:

- rewrite demo institutional content in refined English;
- preserve or add French representations;
- bind high-value entities through Kristal/SenTient;
- update cinematic selectors to stable hooks;
- re-run full demo workflow.

The English demo seed becomes the canonical editorial representation, not a destructive replacement for multilingual data.

## 11. Rollback

During the compatibility window:

- old fields remain populated;
- locale-aware behavior can be feature-flagged;
- representation tables are additive;
- disabling locale resolution returns legacy/default English projection;
- semantic bindings may be ignored by legacy consumers.

Database migrations should avoid irreversible deletion until at least one release cycle after all consumers use stable identity.

## 12. Major-version decision

Because the meaning of identity changes, the semantic contract itself should be treated as a major architectural change even if API compatibility is preserved temporarily.

Any external schema that changes required identity semantics should follow the owning system's major-version/ADR rules.
