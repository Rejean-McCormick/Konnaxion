# Konnaxion Domain and API Changes

**Status:** Architecture proposal

## 1. Migration strategy

The backend refactor SHOULD be additive first.

Do not immediately remove existing `title`, `description` or `content` fields. They are widely consumed and can serve as compatibility projections during migration.

## 2. Stable key for topics and categories

The current demo importer has a stable seed `key`, but topic persistence currently matches by human title. This MUST be changed before multilingual seed import becomes authoritative.

Target principle:

```text
seed key / semantic key → object identity
localized title → representation
```

Conceptual topic fields:

```text
EthikosTopic
  id
  semantic_key               unique, stable
  canonical_language         default "en"
  title                      compatibility projection
  description                compatibility projection
  ...existing fields
```

Category should receive the same treatment if category names are currently used as import identity.

## 3. Representation model

A generic representation table is preferable to adding `title_en`, `title_fr`, etc.

Candidate conceptual model:

```text
LocalizedRepresentation
  id
  object_type
  object_id
  field_name
  language
  text
  kind
  status
  source_language
  source_representation_id
  provenance_json
  created_at
  updated_at
```

A more strongly typed per-domain model is also acceptable if generic content types are undesirable. The key rule is that language is a row dimension, not a schema-column explosion.

## 4. User-authored argument handling

Arguments need stronger semantics than simple translated fields.

Recommended compatibility model:

```text
EthikosArgument
  id
  original_language
  content                  original content during migration
  ...existing fields

ArgumentRepresentation
  argument_id
  language
  content
  kind
  source_representation
  provenance
```

During migration, the existing `content` remains the original authoritative contribution.

## 5. Semantic binding model

Candidate model:

```text
SemanticBinding
  id
  subject_type
  subject_id
  relation
  target_system            wikidata | kristal | konnaxion
  target_id
  resolution_status
  confidence
  source_snapshot_ref
  provenance_json
```

Do not require every subject to have a binding.

## 6. API representation strategy

Recommended API behavior:

```http
GET /api/ethikos/topics/73?lang=fr-CA
```

The response keeps stable identifiers and adds representation metadata.

Example:

```json
{
  "id": 73,
  "semantic_key": "kx:ethikos:topic:canada-us-strategic-dependence",
  "title": "Le Canada devrait-il ... ?",
  "description": "...",
  "representation": {
    "requested_language": "fr-CA",
    "resolved_language": "fr",
    "fallback_used": true,
    "kind": "human_translation"
  }
}
```

Compatibility clients can continue reading `title`.

New clients can inspect representation metadata.

## 7. Original-content API

For user-authored content, API responses SHOULD expose original-language provenance.

Example:

```json
{
  "id": 409,
  "content": "I have publicly campaigned ...",
  "display_language": "en",
  "original": {
    "language": "fr-CA",
    "available": true
  },
  "translation": {
    "kind": "machine_translation",
    "status": "human_reviewed"
  }
}
```

The exact shape needs an API ADR/schema update before implementation.

## 8. Write API

A create request for user content SHOULD carry language explicitly or allow deterministic detection with provenance.

Preferred:

```json
{
  "content": "...",
  "language": "fr-CA"
}
```

If language is detected automatically, store:

- detected language;
- detector/version;
- confidence;
- whether user confirmed it.

## 9. Search API

Search should evolve from text-only matching to a combined strategy:

```text
localized lexical search
+ aliases
+ semantic resolution
+ stable-object deduplication
```

Result identity MUST remain the same regardless of query language.

## 10. Smart Vote and EkoH

The multilingual refactor MUST NOT change weighting mathematics.

Smart Vote and EkoH should consume stable IDs and semantic/domain bindings, not translated labels.

Any UI label or explanation can be localized independently.

## 11. Compatibility period

During the transition:

- existing API fields remain readable;
- `title`/`description` resolve to requested/fallback representation;
- old clients without `lang` receive English default/fallback according to product policy;
- serializers expose stable semantic keys when available;
- importers stop matching by translated text before multilingual seed rollout.
