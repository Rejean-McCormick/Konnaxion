# Target Architecture

**Status:** Architecture proposal

## 1. Architectural objective

The target design makes language a selectable representation over stable semantic/domain identities.

```text
                    External semantic sources
                    Wikidata / Wikibase snapshots
                              │
                              ▼
                         SenTient
                  resolution / ambiguity
                              │
                              ▼
┌──────────────────────────────────────────────────────┐
│                     KRISTAL v5                       │
│ Structured Epistemic State                          │
│ Working / Reference Exchange                        │
│ Runtime Pack                                         │
│ provenance · certainty · validation · authority     │
│ reader policy · labels/aliases/descriptions         │
└─────────────────────────┬────────────────────────────┘
                          │
                semantic references / queries
                          │
              ┌───────────┴───────────┐
              ▼                       ▼
┌───────────────────────────┐  ┌──────────────────────────┐
│        KONNAXION          │  │        ARCHITECT         │
│ domain identity           │  │ deterministic rendering │
│ deliberation graph        │  │ language + locale       │
│ topics/arguments/stances  │  │ trace map               │
│ EkoH / Smart Vote         │  │ no-new-facts            │
│ representation selection  │  └────────────┬─────────────┘
└──────────────┬────────────┘               │
               └──────────────┬─────────────┘
                              ▼
                         Konnaxion UI
                     locale-aware rendering
                              │
                              ▼
                           ARIANE
                stable Atlas + semantic overlay
```

## 2. Responsibility boundaries

### Wikidata/Wikibase

Use for external semantic identity and source data when appropriate.

Examples:

- countries;
- people;
- organizations;
- places;
- technologies;
- concepts and properties represented in the source corpus.

Wikidata is not required to contain Konnaxion-native debates or interaction events.

### SenTient

Owns resolution from surface forms to structured candidates.

Konnaxion SHOULD NOT implement a competing QID/PID resolver.

Language/locale may be an input hint, but ambiguity remains explicit when resolution is not justified.

### Kristal v5

Owns structured epistemic material, deterministic artifacts and the metadata that governs how that material may be interpreted.

For the multilingual update, Kristal is the source for:

- resolved semantic references;
- selected labels, aliases and descriptions;
- source language metadata;
- provenance;
- certainty/status/validation/authority;
- reader-policy constraints;
- deterministic offline packaging.

### Konnaxion

Owns application and deliberative domain objects.

Examples:

- EthikosTopic;
- EthikosArgument;
- stance;
- participant role;
- recusal;
- discussion source binding;
- Smart Vote consultation and reading;
- EkoH contextual signals.

Konnaxion may bind those objects to Kristal/Wikidata semantics without converting them into knowledge assertions.

### Architect

Owns deterministic natural-language rendering from eligible Kristal inputs.

Architect should be used when the output is a language rendering of structured knowledge and traceability matters.

Architect is not required for every static button caption in the UI.

### Ariane

Owns application navigation semantics and map identity.

Existing Ariane namespaces remain authoritative:

- `sc_*` — StateConcept;
- `sv_*` — StateVariant;
- `ec_*` — ElementConcept;
- `qi_*` — Intent;
- `qp_*` — Pattern;
- `qr_*` — SemanticRole;
- `qprop_*` — semantic property.

The multilingual refactor MUST NOT introduce a parallel `ar:*` namespace without a separate Ariane ADR.

## 3. Read flow

For a user requesting `fr-CA`:

```text
request locale = fr-CA
       │
       ├─ UI chrome → message catalog
       │
       ├─ Konnaxion domain object → representation resolver
       │       fr-CA → fr → en → original
       │
       ├─ Kristal-backed entity → local Runtime Pack/query labels
       │
       └─ generated knowledge text → Architect(fr-CA)
```

All branches render the same underlying Konnaxion/Kristal identities.

## 4. Write flow

### Institutional content

```text
create stable Konnaxion object
→ author canonical editorial representation (default: en)
→ bind semantic references
→ add curated translations over time
```

### User-authored content

```text
capture original language + original bytes/text
→ create stable Konnaxion object
→ optional semantic extraction/resolution
→ optional derived translations
→ never overwrite original contribution
```

## 5. Why this is not ordinary i18n

Ordinary i18n solves:

```text
message key → localized UI string
```

This refactor solves:

```text
stable object
+ semantic references
+ original language
+ one or more representations
+ provenance
+ deterministic fallback
+ navigation identity independent of language
```

A normal i18n library remains useful for UI chrome, but it is only one component of the architecture.
