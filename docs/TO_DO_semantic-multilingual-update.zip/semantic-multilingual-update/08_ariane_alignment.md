# Ariane Alignment

**Status:** Architecture proposal  
**Normative source:** existing Ariane documentation remains authoritative for Ariane IDs and Atlas semantics.

## 1. Existing Ariane model already fits the multilingual refactor

Ariane already separates:

- stable StateConcept from StateVariant and runtime Observation;
- ElementConcept from replay locators;
- Transition identity from runtime parameter values;
- structural Core IR from semantic overlay;
- semantic meaning from stack-specific mechanism.

The multilingual update should extend this separation to locale without changing Ariane's core identity model.

## 2. Use existing Ariane semantic IDs

Do not create a parallel semantic namespace.

Use the existing Ariane registry:

```text
qi_*     Intent
qp_*     Pattern
qr_*     SemanticRole
qprop_*  Property
```

Ariane's Semantic Store already supports human labels by BCP-47 language and dialect-specific renderings.

Example from the Ariane model:

```json
{
  "human": {
    "en": "Export as PDF",
    "fr": "Exporter en PDF"
  },
  "dialect": {
    "DIALECT:web-aria": "Export → PDF",
    "DIALECT:windows-uia": "Print → PDF"
  }
}
```

This gives us two independent axes:

```text
human language: en / fr / ...
UI stack dialect: web-aria / windows-uia / ...
```

## 3. Semantic meaning must survive localization

Suppose the Konnaxion UI contains an action whose Ariane intent is:

```text
qi_ethikos_view_readings
```

Possible labels:

```text
en:    View readings
fr-CA: Voir les lectures
```

The intent reference does not change.

Likewise:

```text
ElementConcept ec_...
Transition transition_...
StateConcept sc_...
```

remain stable.

## 4. Accessible name is evidence, not identity

The web-ARIA driver correctly treats accessible roles/names as important observation signals. It also specifies that locator payloads must not become stable identity keys.

For localization, the same principle applies to `name_core` evidence:

- the accessible name can change with locale;
- the ElementConcept should still be recognized through multi-signal anchoring and semantic/contextual evidence;
- localization-aware matching should avoid interpreting an expected translation as UI drift.

## 5. Required Ariane enhancement: locale-aware observation context

Ariane should explicitly include locale in observation/context metadata if it is not already reliably captured for a given driver.

Locale belongs in context/evidence, not in stable element/transition identity unless a genuinely different UI state exists.

Example:

```json
{
  "context": {
    "locale": "fr-CA",
    "dialect_id": "DIALECT:web-aria"
  }
}
```

## 6. Language switch as a transition

A language selector can itself be modeled as a normal Ariane transition.

Example:

```text
source: settings state
trigger: language selector
intent: qi_change_display_language
parameter schema: BCP-47 locale
expected effect: same conceptual app location rendered in requested locale
```

Ariane's existing transition semantics explicitly allow parameterized actions such as selecting `French` from a language dropdown. Parameter values must not influence stable transition identity.

This is exactly the behavior required here.

## 7. Cross-system semantic bridge

Ariane semantics describe UI meaning. Konnaxion semantics describe domain meaning. They should be linked only where useful.

Example:

```text
Ariane Transition
  intent_ref = qi_open_deliberation_topic
  triggers element ec_...

Konnaxion route target
  domain_ref = kx:ethikos:topic:...

Konnaxion topic
  semantic binding → wd:Q16
  semantic binding → wd:Q30
```

Do not collapse these layers into one identifier.

## 8. Proposed Ariane/Konnaxion extension property

If Ariane needs domain-object targeting for robust navigation, add a registered semantic property rather than inventing ad hoc strings.

Candidate:

```text
qprop_domain_object_ref
```

with a value such as:

```text
kx:ethikos:topic:canada-us-strategic-dependence
```

This requires an Ariane registry/ADR update because `qprop_*` is Ariane-owned.

## 9. Drift handling

Locale changes should be classified separately from structural UI drift.

Recommended distinction:

```text
lexical drift       translated label/name changed
structural drift    hierarchy/role/interaction changed
semantic drift      intent/pattern/role meaning changed
```

A translated label by itself should not create a new ElementConcept or StateConcept.

## 10. Testing Ariane multilingual stability

Ariane conformance tests should verify:

- same StateConcept recognized in `en` and `fr-CA`;
- same ElementConcept resolved despite translated accessible name;
- same transition ID executes under both locales;
- locale change does not break anchors;
- destructive-action semantic roles remain identical across translations;
- language-specific labels remain hints/evidence rather than stable IDs.
