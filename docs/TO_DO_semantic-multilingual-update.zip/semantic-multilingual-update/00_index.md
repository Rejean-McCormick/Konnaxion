# Semantic Multilingual Update — Documentation Set

**Status:** Architecture proposal  
**Primary systems:** Konnaxion, Kristal v5, SenTient, Architect, Ariane  
**Purpose:** Define the semantic-first multilingual refactor for Konnaxion without creating a second semantic truth layer.

## Executive decision

Konnaxion will become multilingual by separating **semantic identity** from **linguistic representation**.

The update does **not** define English strings as semantic identity. Instead:

- Wikidata/Wikibase identifiers are reused for external world concepts when appropriate;
- Kristal v5 remains the canonical structured epistemic layer for knowledge, provenance, certainty, validation, authority and deterministic distribution;
- Konnaxion owns stable identities for deliberative/application-domain objects that do not belong in Wikidata;
- English is the default institutional authoring and fallback display language for Konnaxion-owned editorial content;
- original user-authored language is preserved;
- other languages are representations of the same stable Konnaxion or Kristal object;
- Ariane keeps stable navigation identities and semantic intents independent of translated labels.

The result should make switching language operationally similar to switching theme **without making language part of object identity**.

## Documents

1. [01_problem_statement_and_invariants.md](01_problem_statement_and_invariants.md) — why the refactor is required and the invariants it must preserve.
2. [02_target_architecture.md](02_target_architecture.md) — end-to-end target architecture.
3. [03_identity_namespaces_and_bindings.md](03_identity_namespaces_and_bindings.md) — Wikidata, Kristal, Konnaxion and Ariane identity boundaries.
4. [04_multilingual_representation_model.md](04_multilingual_representation_model.md) — language model, original text, translations and fallback.
5. [05_kristal_sentient_architect_integration.md](05_kristal_sentient_architect_integration.md) — how existing Kristal v5 contracts are reused.
6. [06_konnaxion_domain_and_api_changes.md](06_konnaxion_domain_and_api_changes.md) — proposed backend/API changes.
7. [07_frontend_language_runtime.md](07_frontend_language_runtime.md) — frontend locale switching and content resolution.
8. [08_ariane_alignment.md](08_ariane_alignment.md) — semantic navigation alignment and language-independent automation.
9. [09_migration_and_rollout.md](09_migration_and_rollout.md) — additive migration plan and compatibility strategy.
10. [10_testing_conformance_and_observability.md](10_testing_conformance_and_observability.md) — test gates and operational requirements.
11. [ADR-0001-semantic-multilingual-foundation.md](ADR-0001-semantic-multilingual-foundation.md) — proposed architecture decision record.

## Existing contracts this proposal aligns with

### Kristal v5

This proposal treats the following Kristal documents as external normative references rather than duplicating their schemas:

- `00-overview/vision-and-scope.md`
- `03-reproducibility/subset-recipes.md`
- `05-profiles/profile-jsonld-export.md`
- `05-profiles/profile-rdf-wdqs-export.md`
- `06-integration/sentient-resolution-contract.md`
- `06-integration/architect-rendering-contract.md`
- `06-integration/konnaxion-distribution-contract.md`
- `02-schemas/structured-epistemic-state.schema.json`
- `02-schemas/resolved-claim-ir.schema.json`

Relevant Kristal v5 principles already present include:

- Wikidata/Wikibase alignment;
- stable structured identity;
- labels, aliases and descriptions as selectable content;
- BCP-47 language selection in subset recipes and rendering;
- deterministic rendering through Architect;
- ambiguity preservation through SenTient;
- offline Runtime Packs;
- explicit provenance, certainty, validation, authority and reader policy.

### Ariane

This proposal aligns with Ariane's existing semantic architecture rather than inventing a second navigation ontology:

- `DOC-13 — Atlas Data Model`
- `DOC-15 — Element Anchoring & Locators`
- `DOC-16 — Transition Semantics`
- `DOC-31 — Semantic Core`
- `DOC-32 — Semantic Store Format`
- `DOC-34 — Semantic Alignment Rules`
- `drivers/web-aria.md`

Ariane already separates stable concepts from observations and locators, uses stable semantic IDs (`qi_*`, `qp_*`, `qr_*`, `qprop_*`), supports BCP-47 human labels, and explicitly states that semantics should align across stacks similarly to how Wikidata aligns meaning across languages.

## Non-goals

This documentation does not:

- replace Kristal with SKOS, OntoLex, a private Wikibase, or another semantic platform;
- require a live Wikidata endpoint at runtime;
- translate user-authored content destructively;
- make machine translation authoritative by default;
- change Smart Vote, EkoH or deliberative weighting semantics;
- make Ariane depend on visible text as stable identity;
- require every Konnaxion object to have a Wikidata QID.

## Core rule

> A human-visible string may be a representation, source text, label, description or translation. It MUST NOT be the sole identity of an object when a stable semantic or domain identifier exists.
