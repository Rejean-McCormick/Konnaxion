# Problem Statement and Invariants

**Status:** Architecture proposal

## 1. Current problem

Konnaxion currently mixes three concerns that must be separated for a true multilingual system:

1. **Object identity** — what the thing is.
2. **Semantic meaning** — what external or internal concepts the thing refers to.
3. **Human language** — how the thing is expressed to a user.

The current Ethikos shape makes this visible: topics expose fields such as `title` and `description`, arguments expose a single `content`, and demo import currently resolves a topic using the title text. That makes text participate in operational identity.

A translation can therefore accidentally behave like a new object.

That is incompatible with a semantic multilingual design.

## 2. Desired behavior

Changing locale from `en` to `fr-CA` must not change:

- topic identity;
- argument identity;
- stance identity;
- parent/child relationships;
- source bindings;
- Smart Vote consultation bindings;
- EkoH context;
- recusal state;
- semantic bindings;
- Ariane state, element or transition identity.

Only the selected human representation should change.

## 3. Normative invariants

### I1 — Identity is language-neutral

Stable object identity MUST NOT depend on a translated title, description, label or button caption.

### I2 — English is a fallback representation, not semantic identity

Konnaxion MAY adopt English as:

- the default institutional authoring language;
- the canonical editorial representation for maintained product/demo content;
- the fallback display language when no requested representation exists.

English MUST NOT become the primary key or semantic identity of a concept.

### I3 — Original human speech is preserved

User-authored contributions MUST retain:

- original text;
- original language;
- author;
- timestamp;
- provenance.

A translated rendering MUST be stored or exposed as a derived representation, not as a destructive replacement.

### I4 — Wikidata is an external semantic authority, not the identity space for all Konnaxion objects

Use Wikidata/Wikibase IDs where the object is an external concept or entity and the mapping is justified.

Do not create fake QIDs for:

- a Konnaxion discussion topic;
- an Ethikos argument;
- a recusal event;
- a Smart Vote reading;
- an Ariane transition.

Those need Konnaxion or Ariane identities.

### I5 — No live-network correctness dependency

Semantic display and language switching MUST continue to function from pinned/local data when the network is unavailable.

This matches Kristal v5 Runtime Pack and deterministic rendering constraints.

### I6 — Translation cannot alter epistemic status

Changing language MUST NOT change:

- certainty;
- assertion status;
- validation status;
- validated-as mode;
- authority channel;
- scope;
- reader-policy eligibility.

### I7 — Deliberation does not mutate knowledge canon

Konnaxion may deliberate about Kristal-backed knowledge, reference it and attach arguments to it. Votes, EkoH signals and Smart Vote readings MUST NOT silently mutate the underlying Kristal knowledge artifact.

### I8 — Ariane navigation identity is not visible text

Ariane MAY use accessible names or visible labels as recognition evidence. These MUST NOT be stable identity keys.

Stable Ariane concepts, element concepts and transitions remain independent of locale.

### I9 — Fallback is deterministic

For a requested locale, representation selection MUST follow an explicit ordered fallback policy. The same inputs and locale must select the same representation.

Recommended initial policy:

```text
requested exact locale
→ requested base language
→ canonical/default representation language
→ original representation, if different and allowed
→ explicit missing-representation state
```

Example:

```text
fr-CA → fr → en → original → missing
```

### I10 — Provenance remains visible to machines

Derived translations and Architect renderings MUST retain enough metadata to answer:

- what source object was rendered;
- which source language was used;
- which language was requested;
- which rendering/translation mechanism produced the output;
- which version/profile produced it;
- whether it is human-authored, imported, curated or machine-rendered.

## 4. Three classes of language

The refactor MUST distinguish:

### A. UI chrome

Examples: `Open thread`, `Refresh`, `View readings`.

These are product messages. They belong in a frontend/backend message catalog, not Kristal truth artifacts.

### B. Konnaxion domain content

Examples: topic titles, institutional descriptions, moderation templates, curated demo text.

These have Konnaxion object identity and multilingual representations.

### C. Knowledge-backed or user-authored content

Examples: factual summaries generated from Kristal, quotations, user arguments.

These require provenance and must preserve original content or source assertions.

Treating all three categories with one translation mechanism would be an architectural error.
