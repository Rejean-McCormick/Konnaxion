# Identity, Namespaces and Semantic Bindings

**Status:** Architecture proposal

## 1. Identity classes

The system MUST distinguish four identity classes.

| Class | Owner | Examples | Language-dependent? |
|---|---|---|---|
| External semantic identity | Wikidata/Wikibase | `Q16`, `Q30`, `P31` | No |
| Kristal artifact/assertion identity | Kristal | `kristal_id`, `assertion_id`, `statement_id` | Identity follows Kristal contract |
| Konnaxion domain identity | Konnaxion | topic, argument, recusal, consultation | No |
| Ariane navigation identity | Ariane | `sc_*`, `sv_*`, `ec_*`, transition ID, `qi_*` | No |

## 2. Konnaxion semantic keys

Konnaxion objects that must survive database migration, seed re-import and language changes SHOULD receive an explicit stable semantic/domain key.

Recommended form:

```text
kx:ethikos:topic:canada-us-strategic-dependence
kx:ethikos:argument:<stable-id>
kx:smart-vote:consultation:<stable-id>
```

The exact serialization may be a slug, URN or namespaced string. The important property is stability and language independence.

A database integer primary key may remain the storage identity. The semantic/domain key provides durable external/reference identity.

## 3. Semantic bindings

A Konnaxion object may refer to one or more semantic objects.

Recommended conceptual shape:

```json
{
  "subject_ref": "kx:ethikos:topic:canada-us-strategic-dependence",
  "relation": "jurisdiction",
  "target": {
    "system": "wikidata",
    "id": "Q16"
  },
  "resolution": {
    "source": "sentient",
    "confidence": 1.0,
    "status": "resolved"
  },
  "provenance": {
    "source_snapshot_ref": "sha256:..."
  }
}
```

The binding is not a statement that Wikidata endorses the debate question. It means the Konnaxion object refers to that semantic entity in the declared role.

## 4. Binding roles

Binding roles SHOULD be explicit and finite rather than free-text where practical.

Candidate roles:

- `subject`;
- `jurisdiction`;
- `counterparty`;
- `mentioned_entity`;
- `affected_domain`;
- `location`;
- `organization`;
- `person`;
- `technology`;
- `evidence_entity`.

Do not overload Wikidata PIDs to represent every Konnaxion-specific relationship. A Konnaxion binding role is allowed to be domain-specific.

## 5. Resolution states

Semantic resolution MUST support at least:

```text
resolved
ambiguous
local_only
unresolved
```

A missing QID MUST NOT make a Konnaxion object invalid.

### resolved

One external semantic target is selected with sufficient justification.

### ambiguous

Multiple candidates remain plausible. Preserve them; do not silently choose one.

### local_only

The concept is valid in Konnaxion but is intentionally not represented by an external Wikidata object.

### unresolved

Resolution has not yet succeeded or has not been attempted.

## 6. What must never be identity

The following MUST NOT be sole stable identity keys:

- translated title;
- translated description;
- visible button label;
- accessible name;
- CSS selector;
- XPath;
- current list position;
- source language;
- current locale.

This aligns with Ariane's rule that locators are replay hints and not stable identity keys.

## 7. Ariane cross-reference

Konnaxion domain identities and Ariane navigation identities should be linked, not merged.

Example:

```text
Konnaxion domain object
kx:ethikos:topic:canada-us-strategic-dependence

rendered in Ariane state concept
sc_ethikos_deliberation_topic

opened by Ariane transition
transition:<stable-id>
  intent_ref = qi_open_deliberation_topic
```

The same `sc_*` / transition remains valid when the visible topic title changes language.

## 8. No parallel semantic canon

Do not introduce a second canonical KG in Konnaxion merely to support multilingual labels.

Konnaxion should persist:

- durable domain identity;
- references/bindings;
- representation metadata;
- local cache/projection data required by runtime.

Kristal remains the canonical structured epistemic contract for knowledge artifacts.
