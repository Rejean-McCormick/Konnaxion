# Kristal, SenTient and Architect Integration

**Status:** Architecture proposal  
**External normative reference:** Kristal v5

## 1. Do not duplicate Kristal

The multilingual refactor should implement the capabilities already anticipated by Kristal v5 instead of adding a competing semantic framework.

Kristal v5 already provides the relevant architectural primitives:

- Wikidata/Wikibase alignment;
- Structured Epistemic State;
- QID/PID resolution workflows;
- labels, aliases and descriptions as selectable material;
- BCP-47 language selection in subset recipes;
- deterministic JSON-LD / RDF-WDQS projections;
- provenance, certainty, validation and authority;
- Reader Policy;
- deterministic multilingual Architect rendering;
- offline Runtime Packs.

## 2. Semantic ingestion path

Recommended path:

```text
source text / dataset / Wikidata snapshot
              │
              ▼
      Structured Epistemic State
              │
              ├─ optional extractor proposal path
              │
              ▼
           SenTient
      candidate QIDs/PIDs
      explicit ambiguity
              │
              ▼
          validation
              │
              ▼
     Working/Reference Exchange
              │
              ▼
          Runtime Pack
```

Konnaxion should consume the result through declared contracts rather than call Wikidata ad hoc for runtime correctness.

## 3. Language data in Runtime Packs

Subset recipes already support a `LABELS_AND_DESCRIPTIONS` expansion rule with:

```json
{
  "kind": "LABELS_AND_DESCRIPTIONS",
  "params": {
    "languages": ["en", "fr"],
    "include_aliases": true,
    "include_descriptions": true
  }
}
```

Konnaxion deployment profiles SHOULD declare the languages required for the intended audience.

Example initial policy:

```text
core product packs: en, fr
Canada public-sector pack: en, fr, fr-CA where source distinctions exist
```

The exact pack language policy should be explicit and reproducible.

## 4. SenTient role

SenTient owns semantic resolution.

Konnaxion MAY send:

- surface text;
- source language/locale;
- context;
- candidate constraints;
- tenant/app hints where supported.

Konnaxion MUST preserve unresolved ambiguity returned by SenTient.

Bad:

```text
"Washington" → force Q61 because it is top-ranked
```

Good:

```text
"Washington"
→ candidates
→ unresolved/ambiguous until context justifies selection
```

## 5. Architect role

Architect is used for deterministic language output derived from eligible Kristal material.

A render request should include, per Kristal contract:

- render kind;
- BCP-47 language;
- template/render profile and version;
- Reader Policy;
- projection and constraints;
- optional locale/tone/audience fields that do not alter facts.

Architect output must retain traceability to source assertions/evidence and preserve assertion status, certainty, validation, authority and scope.

## 6. Architect is not the UI message catalog

Do not use Architect to render every static product label.

Use Architect for:

- knowledge cards;
- factual summaries;
- explainability text generated from Kristal;
- semantic entity descriptions where a deterministic render is required;
- cross-language knowledge-backed reports.

Use ordinary application i18n for:

- `Save`;
- `Cancel`;
- `Open thread`;
- validation form labels;
- menu captions;
- generic error messages.

## 7. Reader Policy and language

Kristal v5 Reader Policy introduces an important constraint: language rendering and epistemic selection are separate decisions.

Example:

```text
reader policy = validated_only
language = fr-CA
```

The system first selects which assertions are eligible under the reader policy, then renders the eligible material in `fr-CA`.

Changing language MUST NOT broaden or narrow epistemic eligibility unless the active reader policy explicitly includes language constraints.

## 8. Wikidata updates

Wikidata is mutable. Runtime correctness should use pinned snapshots or Kristal artifacts.

A refresh flow should be explicit:

```text
new Wikidata snapshot
→ rebuild/re-resolve
→ validation
→ new Kristal artifact identity
→ controlled Konnaxion activation
```

Do not make page rendering depend on a live Wikidata API call returning the same label forever.

## 9. Optional OSS implementation libraries

Libraries such as RDFLib or pySHACL MAY implement Kristal profiles where useful.

They are implementation choices, not semantic authorities.

The contract remains Kristal v5.
