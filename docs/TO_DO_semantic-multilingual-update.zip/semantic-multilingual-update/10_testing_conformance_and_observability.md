# Testing, Conformance and Observability

**Status:** Architecture proposal

## 1. Required test families

The refactor is complete only when identity, language selection and semantic provenance are tested independently.

## 2. Identity tests

Required assertions:

- translating a topic title does not change topic ID;
- importing the same semantic key in another language updates/creates a representation, not another topic;
- category translation does not duplicate category identity;
- argument translation does not change parent/child graph;
- Smart Vote source binding remains identical across locales;
- EkoH relevance/weights remain identical across locales.

## 3. Fallback tests

For each supported locale, test exact fallback order.

Example fixture:

```text
representations: en, fr
request: fr-CA
expected resolved: fr
fallback_used: true
```

Also test missing-language behavior explicitly.

## 4. Original-content tests

For user-authored contributions:

- original bytes/text remain unchanged after translation generation;
- original language remains recorded;
- translation references original representation;
- deleting/superseding translation does not delete original;
- original can be retrieved where policy permits.

## 5. Semantic binding tests

- QID/PID binding retains source snapshot/provenance;
- ambiguous SenTient result remains ambiguous unless an explicit resolution is recorded;
- local-only objects remain valid;
- language change cannot change selected semantic target by itself;
- semantic binding changes are audited/versioned.

## 6. Kristal contract tests

Use the Kristal v5 conformance suite for any implementation claiming those profiles.

Konnaxion-specific integration tests should verify:

- pinned Runtime Pack activates and resolves required labels offline;
- requested languages were included by the subset recipe;
- Reader Policy filtering is unchanged by display language;
- Architect output preserves trace metadata;
- unsupported/ambiguous factual renders fail or label ambiguity as required.

## 7. API tests

Required matrix:

| Request | Expected |
|---|---|
| no `lang` | default product language/fallback |
| `lang=en` | English representation |
| `lang=fr` | French representation if available |
| `lang=fr-CA` with only `fr` | deterministic fallback to `fr` |
| unsupported language | documented fallback or 4xx policy |

Stable IDs must be identical in every row.

## 8. Frontend tests

- language switch persists after reload;
- `<html lang>` updates;
- Ant Design locale changes;
- UI chrome translates;
- domain content translates independently;
- currently open topic/drawer remains on same object;
- translated user content is marked;
- original-content toggle works;
- dates/numbers use locale formatting without changing underlying values.

## 9. Ariane conformance tests

For the same Konnaxion flow under `en` and `fr-CA`:

- same `sc_*` concept matched;
- same `ec_*` concept matched;
- same transition identity selected;
- same `qi_*` intent attached;
- localized accessible names do not create false drift;
- locator fallbacks do not become identity;
- language-switch transition changes context locale as expected.

## 10. Cinematic/Playwright regression

Existing walkthrough tests should be migrated toward stable selectors before multilingual copy is enabled.

Rule:

```text
behavior locator != translated text assertion
```

Good:

```text
locate by stable test/semantic hook
assert visible text is expected English/French translation
```

Bad:

```text
locate every critical control only by English text
```

## 11. Observability

Recommended structured fields:

```text
requested_locale
resolved_locale
fallback_used
representation_kind
representation_id
source_language
semantic_binding_status
semantic_target_system
semantic_target_id
kristal_id/runtime_pack_id
architect_render_id/profile
ariane_state_concept_id
ariane_transition_id
```

Avoid logging raw private user text solely for localization diagnostics.

## 12. Success criteria

The update is production-ready when:

1. a user can switch `en ↔ fr-CA` without changing domain identity;
2. the same Ethikos discussion graph and Smart Vote result are retained;
3. original user contributions are preserved;
4. semantic QID/PID bindings remain stable across locales;
5. the required language data works offline from pinned artifacts;
6. Ariane navigates the same flow in both languages without language-specific Atlas forks;
7. old clients remain functional through the declared compatibility window.
