# ADR-0001 — Semantic Multilingual Foundation

**Status:** Proposed  
**Date:** 2026-08-22  
**Decision owners:** Konnaxion / kOA architecture, with Kristal and Ariane contract owners for their respective boundaries

## Context

Konnaxion currently stores and consumes human-readable strings in places where those strings can participate in lookup, import behavior and UI automation. This makes true multilingual operation difficult because translating a string can accidentally change operational identity.

The ecosystem already contains two relevant semantic foundations:

1. **Kristal v5**, which is Wikidata/Wikibase-aligned, provenance-aware, certainty/validation/authority-aware, offline-capable and supports deterministic multilingual rendering through Architect.
2. **Ariane**, which already separates stable UI concepts from observations and locators and defines semantic intents, patterns and roles with multilingual BCP-47 labels.

Adding a third independent semantic model inside Konnaxion would create duplication and drift.

## Decision

Konnaxion will adopt a semantic-first multilingual architecture with the following rules.

### D1 — Stable domain identity

Konnaxion-owned domain objects will receive or expose stable language-neutral keys where persistence/import/interoperability requires them.

Human-readable titles and names will not be stable lookup identity.

### D2 — English editorial default

English will be the default canonical editorial/fallback language for Konnaxion-maintained institutional content.

English strings are representations, not semantic identity.

### D3 — Original user language preservation

User-authored content retains its original text and language. Translations are derived representations with provenance.

### D4 — Wikidata/Kristal semantic bindings

Konnaxion will reference Wikidata/Kristal semantics through explicit bindings rather than copying or recreating a complete semantic graph.

Objects without a valid Wikidata mapping remain valid Konnaxion-local objects.

### D5 — SenTient resolution

QID/PID resolution is delegated to SenTient/Kristal workflows. Ambiguity must remain explicit.

### D6 — Architect rendering

Architect is used for deterministic knowledge-backed multilingual rendering where traceability matters. It is not the static UI message catalog.

### D7 — Ariane alignment

Konnaxion will align automation with Ariane's existing `sc_*`, `sv_*`, `ec_*`, `qi_*`, `qp_*`, `qr_*`, `qprop_*` contracts.

Visible translated strings and locators are not Ariane stable identity.

### D8 — Additive migration

Existing text fields and API shapes remain compatibility projections during migration. Stable keys and representations are introduced before destructive cleanup.

## Consequences

### Positive

- language switch no longer changes logical object identity;
- English and French can coexist without duplicate Ethikos topics;
- semantic search can converge across languages;
- user-authored provenance is preserved;
- Kristal capabilities are reused instead of duplicated;
- offline multilingual rendering remains possible;
- Ariane navigation becomes more robust to localization;
- Playwright/cinematic selectors can move toward stable semantic/test hooks.

### Costs

- major backend data-model work;
- importer migration;
- locale-aware API contracts;
- translation/provenance lifecycle;
- search/index changes;
- new conformance matrix;
- migration of brittle text selectors;
- cross-project coordination with Ariane/Kristal owners.

## Rejected alternatives

### A. Translate the database in place

Rejected because it destroys original language and keeps text as identity.

### B. Add `title_en`, `title_fr`, ... columns

Rejected as non-scalable and inadequate for provenance, user-authored text and arbitrary BCP-47 locales.

### C. Introduce a new private Wikibase as the semantic core

Rejected for the initial design because Kristal already defines the semantic/epistemic contract and a new canon would duplicate responsibilities.

### D. Use SKOS/OntoLex as the primary Konnaxion model

Rejected as the primary architecture. They remain possible interoperability/export tools if a concrete requirement emerges. Kristal remains the contract boundary.

### E. Let Ariane use visible translated names as action identity

Rejected because localization would fork navigation identity and make automation brittle.

## Required follow-up decisions

1. Exact Konnaxion semantic key syntax.
2. Exact representation table/schema.
3. Initial supported locale set.
4. Representation publication/review workflow.
5. Semantic binding relation vocabulary.
6. API locale transport and fallback contract.
7. Ariane extension, if any, for Konnaxion domain-object references.
8. Frontend i18n library choice for UI chrome.
9. Translation provider/process for non-Architect content.
10. Migration schedule for removal of title/name-based importer identity.

## Acceptance criteria

This ADR is implemented when:

- stable domain identity is independent of language;
- multilingual representations can coexist;
- original user content is preserved;
- semantic bindings are provenance-bearing;
- Konnaxion consumes Kristal/SenTient/Architect contracts without redefining them;
- Ariane can navigate equivalent English/French UI states without duplicate semantic identity;
- existing consumers have a documented compatibility path.
