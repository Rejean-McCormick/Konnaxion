# Multilingual Representation Model

**Status:** Architecture proposal

## 1. Principle

A representation is language-specific content attached to a stable object.

```text
stable object identity
      ├─ en representation
      ├─ fr representation
      └─ other representations
```

The representation is not the object.

## 2. Representation categories

The model SHOULD distinguish at least:

- `original` — exact user/source-authored representation;
- `canonical_editorial` — maintained institutional representation;
- `human_translation` — curated translation;
- `machine_translation` — derived translation;
- `architect_render` — deterministic knowledge-backed render;
- `imported_label` — imported semantic label/description/alias.

## 3. Proposed representation record

Conceptual shape:

```json
{
  "representation_id": "uuid-or-stable-id",
  "object_ref": "kx:ethikos:topic:canada-us-strategic-dependence",
  "field": "title",
  "language": "fr-CA",
  "text": "Le Canada devrait-il réduire sa dépendance stratégique... ?",
  "kind": "human_translation",
  "source_language": "en",
  "status": "published",
  "provenance": {
    "producer": "human",
    "producer_id": "...",
    "source_representation_id": "...",
    "profile_id": null,
    "profile_version": null
  }
}
```

This is a Konnaxion-domain representation record. It is not intended to replace Kristal render bundles or Kristal label structures.

## 4. Canonical editorial language

For Konnaxion-maintained institutional content, the initial policy SHOULD be:

```text
canonical_editorial_language = en
```

This means English is the maintained source representation used for:

- official demo seed copy;
- curated product examples;
- Konnaxion-authored topic descriptions;
- institutional templates where Konnaxion is the author.

It does not mean:

- all users must write in English;
- English text is object identity;
- an English version overwrites original French content;
- all Kristal knowledge is English-only.

## 5. User-authored content

For a user argument:

```json
{
  "argument_id": "kx:ethikos:argument:1234",
  "original_language": "fr-CA",
  "original_content": "..."
}
```

Translations are attached separately.

The UI MUST be able to indicate when a displayed argument is translated.

Recommended metadata visible on demand:

```text
Translated from French (Canada)
Original available
```

## 6. Translation authority

A translation SHOULD carry trust/provenance metadata.

Recommended statuses:

```text
draft
machine_generated
human_reviewed
published
superseded
```

Machine-generated translations MUST NOT silently become the authoritative original.

## 7. Deterministic fallback

Recommended initial resolver:

```python
resolve(locale, representations):
    candidates = [
        exact(locale),
        base_language(locale),
        canonical_editorial_language,
        original_language,
    ]
    return first_published_match(candidates)
```

The fallback chain SHOULD be stored/configured centrally and covered by tests.

## 8. Locale vs language

Use BCP-47 tags where language affects rendering.

Examples:

```text
en
fr
fr-CA
en-CA
ar
```

Do not use display strings such as `French` as database language identity.

## 9. Fields requiring representations

Initial Ethikos candidates:

### Category

- `name`;
- `description`.

### Topic

- `title`;
- `description`.

### Argument

- `content` — with original-preservation semantics.

### ArgumentSource

Depending on source kind:

- `title`;
- `excerpt`;
- `citation_text`;
- `quote`;
- `note`.

Quoted source text SHOULD normally preserve the source language and be translated as a separate rendering rather than replacing the quote.

## 10. Kristal-backed labels and descriptions

When a visible string is a semantic label/description already carried by Kristal/Wikidata-derived data, Konnaxion SHOULD consume that representation rather than copying it into a new Konnaxion translation table without need.

The Konnaxion representation layer is for Konnaxion-owned domain content and derived user-content translations, not a duplicate of Kristal's semantic label store.

## 11. Search implications

Search SHOULD support:

- exact/normalized search over available representations;
- aliases imported from Kristal when available;
- semantic resolution through SenTient;
- returning one stable object regardless of query language.

A French search and an English search may therefore resolve to the same topic ID.
