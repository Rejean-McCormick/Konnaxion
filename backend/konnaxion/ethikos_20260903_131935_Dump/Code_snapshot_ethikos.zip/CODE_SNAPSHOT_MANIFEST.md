# Code snapshot

- generated_at: 2026-09-03T13:19:35.823416
- repository: ethikos
- archive_layout: repository-relative paths

## Snapshot files
- `__init__.py` (47 bytes)
- `admin.py` (17247 bytes)
- `api_views.py` (30760 bytes)
- `apps.py` (205 bytes)
- `constants.py` (8565 bytes)
- `demo_import/__init__.py` (322 bytes)
- `demo_import/importer.py` (47495 bytes)
- `demo_import/schema.py` (34572 bytes)
- `demo_import/serializers.py` (15674 bytes)
- `demo_import/urls.py` (1064 bytes)
- `demo_import/views.py` (3410 bytes)
- `management/__init__.py` (0 bytes)
- `management/commands/__init__.py` (0 bytes)
- `management/commands/seed_ethikos_workflow.py` (9467 bytes)
- `migrations/0001_initial.py` (3671 bytes)
- `migrations/0002_initial.py` (2241 bytes)
- `migrations/0003_kintsugi_wave1_korum.py` (18808 bytes)
- `migrations/0004_demoscenarioimport.py` (2778 bytes)
- `migrations/0005_demo_import_v3_object_types.py` (1336 bytes)
- `migrations/__init__.py` (58 bytes)
- `models.py` (13752 bytes)
- `models_demo.py` (4028 bytes)
- `permissions.py` (9790 bytes)
- `serializers.py` (18458 bytes)
- `tests.py` (9964 bytes)
- `tests/test_demo_import_api.py` (12981 bytes)
- `tests/test_demo_import_schema.py` (13387 bytes)
- `tests/test_demo_importer.py` (14412 bytes)
- `tests/test_kintsugi_korum_api.py` (32183 bytes)
- `tests/test_kintsugi_korum_models.py` (13788 bytes)
- `urls.py` (1814 bytes)
- `views.py` (1695 bytes)
