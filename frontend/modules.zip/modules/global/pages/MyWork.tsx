"use client";
import AppShell from "../components/AppShell";

export default function MyWork() {
  return (
    <AppShell>
      <h1 className="text-xl font-semibold mb-4">My work</h1>
      <p>Coming soon…</p>
    </AppShell>
  );
}
