﻿export { default as useGlobalSearch } from './useGlobalSearch';
