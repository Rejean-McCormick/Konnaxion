export default function DomainHeatMap() {
  return (
    <div style={{ minHeight: 300, display: "flex", alignItems: "center", justifyContent: "center", color: "#bbb" }}>
      {/* TODO: Implement heatmap with Chart.js or another library */}
      <em>Heatmap chart not available (react-chartjs-2-heatmap does not exist)</em>
    </div>
  );
}
