﻿export default function Stub() { return null }
