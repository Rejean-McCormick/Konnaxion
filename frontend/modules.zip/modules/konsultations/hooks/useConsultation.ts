﻿export default function stub() { /* TODO */ }
