import { PollPage } from "@/modules/konsensus/pages";
export default PollPage;
