export { default as PollPage } from './PollPage';
